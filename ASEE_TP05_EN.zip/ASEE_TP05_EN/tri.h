

void lire(int t[],int n);
void afficher(int t[],int n);
void copier(int t_src[],int t_dest[],int n);


void tri_permutation(int t[],int n);
void tri_bulle(int t[],int n);
void tri_selection(int t[],int n);
void tri_rapide(int t[],int debut,int fin);


