#include <stdio.h>
#include <tri.h>



int main()
{
    int n; //taille du tableau

    printf("--------------------------------------\n");
    printf("----Comparaison Algorithmes de tri----\n");
    printf("--------------------------------------\n");
    //lecture de la taille du tableau
    printf("donner la taille du tableau:");
    scanf("%d",&n);
    int t[n]; //tableau � trier



    printf("--------------FIN---------------------\n");
    return 0;
}
