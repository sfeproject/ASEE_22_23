#include <stdio.h>
void tri_permutation(int t[],int n){
    int i,j,k,c;
    for(i=1;i<n;i++) {
        if ( t[i] < t[i-1] ) {
            j = 0;
            while ( t[j] < t[i] )
                j++;
                c = t[i];
                for( k = i-1 ; k >= j ; k-- )
                t[k+1] = t[k];
                t[j] = c ;
            }
    }

}
