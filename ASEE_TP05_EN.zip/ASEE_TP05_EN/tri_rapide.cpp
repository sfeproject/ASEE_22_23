#include <stdio.h>
void tri_rapide(int t[],int debut,int fin){


}
