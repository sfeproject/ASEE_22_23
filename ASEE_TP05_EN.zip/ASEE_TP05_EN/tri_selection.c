#include <stdio.h>
void tri_selection(int t[],int n){
    int i,j,c;
    for(i=0;i<n-1;i++)
        for(j=i+1;j<n;j++)
            if ( t[i] > t[j] ) {
                c = t[i];
                t[i] = t[j];
                t[j] = c;
            }

}
