#include <stdio.h>
void tri_bulle(int t[],int n){
    int i,j,c;
    for(j=1;j<=n;j++) // pour faire l'operation n fois
        for(i=0;i<n-1;i++)
            if ( t[i] > t[i+1] ) {
                c = t[i];
                t[i] = t[i+1];
                t[i+1] = c;
        }

}
